async function sendReaction(chatId, messageId, emoji, log, error) {
  try {
    const response = await fetch(
      `https://api.telegram.org/bot${process.env.TELEGRAM_TOKEN}/sendReaction`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          message_id: messageId,
          reaction: [{ type: 'emoji', emoji }],
        }),
      }
    );
    const data = await response.json();
    if (!data.ok) throw new Error(`Reaction failed: ${data.description}`);
    log(`Added reaction ${emoji} to message ${messageId} in chat ${chatId}`);
  } catch (e) {
    error(`Reaction error: ${e.message}`);
  }
}

module.exports = { sendReaction };
