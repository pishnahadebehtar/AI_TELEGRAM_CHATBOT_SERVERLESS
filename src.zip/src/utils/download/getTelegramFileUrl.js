async function getTelegramFileUrl(fileId, error) {
  try {
    const response = await fetch(
      `https://api.telegram.org/bot${process.env.TELEGRAM_TOKEN}/getFile?file_id=${fileId}`
    );
    const data = await response.json();
    if (!data.ok) throw new Error(`Failed to get file: ${data.description}`);
    return `https://api.telegram.org/file/bot${process.env.TELEGRAM_TOKEN}/${data.result.file_path}`;
  } catch (e) {
    error(`getTelegramFileUrl error: ${e.message}`);
    throw e;
  }
}

module.exports = { getTelegramFileUrl };
