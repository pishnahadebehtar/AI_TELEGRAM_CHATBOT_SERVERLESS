function getMessageType(message) {
  if (!message) return 'پیام نامشخص';
  if (message.photo) return 'عکس';
  if (message.video) return 'ویدیو';
  if (message.document) return message.document.file_name || 'فایل';
  if (message.sticker) return 'استیکر';
  if (message.audio) return 'صدا';
  if (message.animation) return 'انیمیشن';
  return 'پیام غیرمتنی';
}

module.exports = { getMessageType };
