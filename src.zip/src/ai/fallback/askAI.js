const { getGenerativeModel } = require('../generation/getGenerativeModel.js');

module.exports.askAI = async function (prompt, error) {
  try {
    const response = await getGenerativeModel(
      prompt,
      'Text Generation',
      'gemini-2.0-flash',
      0
    );
    return response.text.trim();
  } catch (e) {
    error(`Gemini error: ${e.message}`);
    console.log('Falling back to OpenRouter');
    try {
      const requestBody = {
        model: process.env.MODEL,
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 600,
      };
      const headers = {
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
      };
      const r = await fetch('https://openrouter.ai/api/v1/chat/completions', {
        method: 'POST',
        headers,
        body: JSON.stringify(requestBody),
      });
      if (!r.ok) throw new Error(`OpenRouter error: ${await r.text()}`);
      const d = await r.json();
      if (!d.choices || !d.choices[0] || !d.choices[0].message) {
        throw new Error('Invalid OpenRouter response');
      }
      let responseText = d.choices[0].message.content;
      return responseText;
    } catch (openError) {
      error(`OpenRouter error: ${openError.message}`);
      return `⚠️ خطا در دریافت پاسخ از هوش مصنوعی. لطفاً دوباره تلاش کنید یا برای مشاوره حقوقی رایگان دکمه زیر را فشار دهید.`;
    }
  }
};
