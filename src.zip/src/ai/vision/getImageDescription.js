const {
  getTelegramFileUrl,
} = require('../../utils/download/getTelegramFileUrl.js');

async function getImageDescription(fileId, log, error) {
  try {
    if (!fileId) throw new Error('No file_id provided for image description');

    const imageUrl = await getTelegramFileUrl(fileId, error);
    log(`Fetching image description for URL: ${imageUrl}`);

    const requestBody = {
      prompt: null,
      image: imageUrl,
    };
    const headers = {
      Authorization: `Bearer ${process.env.VISION_GENERATOR_API_KEY}`,
      'Content-Type': 'application/json',
    };

    const visionUrl = process.env.VISION_GENERATOR_URL;
    if (!visionUrl) throw new Error('VISION_GENERATOR_URL is not defined');

    const response = await fetch(visionUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Vision API error: ${response.status} - ${errText}`);
    }

    const data = await response.json();
    if (!data.response) throw new Error('Invalid response from Vision API');

    const description = data.response.trim();
    log(`Image description: ${description.slice(0, 100)}...`);
    return description;
  } catch (e) {
    error(`getImageDescription error: ${e.message}`);
    return null;
  }
}

module.exports = { getImageDescription };
