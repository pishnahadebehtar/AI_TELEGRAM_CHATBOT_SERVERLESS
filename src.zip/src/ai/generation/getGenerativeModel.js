const { genAI } = require('../../config.js');
const { HarmCategory, HarmBlockThreshold } = require('@google/generative-ai');

async function getGenerativeModel(
  content,
  task,
  preferredModel = 'gemini-2.0-flash',
  retryCount = 0,
  enableSearch = false
) {
  const stepName = task;
  const retries = 3;
  const baseDelay = 1000;

  const modelVariants = [
    'gemini-2.0-flash',
    'gemini-2.5-flash',
    'gemini-1.5-flash',
  ];

  console.log(
    `[${stepName}] Starting with model ${preferredModel} (enableSearch: ${enableSearch})`
  );

  let lastError = null;

  // Define search tool
  const searchTool = {
    functionDeclarations: [
      {
        name: 'web_search',
        description:
          'جستجوی وب برای اطلاعات به‌روز و مرتبط. فقط وقتی اطلاعات تازه یا خارج از دانش داخلی لازم است استفاده کنید.',
        parameters: {
          type: 'object',
          properties: {
            query: {
              type: 'string',
              description: 'پرس‌وجوی جستجو به انگلیسی یا پارسی',
            },
          },
          required: ['query'],
        },
      },
    ],
  };

  // Helper to create and call model
  const attemptCall = async (modelName, attempt = 0) => {
    try {
      console.log(
        `[${stepName}] Attempt ${attempt + 1}/${retries} with model ${modelName}`
      );

      const modelConfig = {
        model: modelName,
        safetySettings: [
          {
            category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
            threshold: HarmBlockThreshold.BLOCK_NONE,
          },
        ],
      };

      if (enableSearch) {
        modelConfig.tools = [searchTool];
      }

      const generativeModel = genAI.getGenerativeModel(modelConfig);

      // Generate content
      const generateResult = await generativeModel.generateContent(content);
      let response = await generateResult.response;
      let responseText = '';

      // Tool calling loop
      let toolIterations = 0;
      const maxToolIterations = 3;
      while (
        response.candidates?.[0]?.content?.parts?.some(
          (part) => part.functionCall
        ) &&
        toolIterations < maxToolIterations
      ) {
        const functionCall = response.candidates[0].content.parts.find(
          (part) => part.functionCall
        )?.functionCall;
        if (functionCall?.name === 'web_search') {
          const query = functionCall.args?.query;
          console.log(`[${stepName}] Executing web_search for query: ${query}`);

          const searchResponse = await fetch(
            `https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`
          );
          if (!searchResponse.ok)
            throw new Error(`Search API failed: ${searchResponse.status}`);
          const searchData = await searchResponse.json();
          const searchResult =
            searchData.Abstract ||
            searchData.RelatedTopics?.map((t) => t.Text).join('\n') ||
            'No results found';

          const toolResponse = {
            functionResponse: {
              name: functionCall.name,
              response: { result: searchResult },
            },
          };
          const updatedContent = Array.isArray(content)
            ? [...content, toolResponse]
            : [content, toolResponse];
          content = updatedContent;

          const newGenerateResult =
            await generativeModel.generateContent(content);
          response = await newGenerateResult.response;
          toolIterations++;
        } else {
          break;
        }
      }

      // Extract text
      if (
        response.candidates &&
        response.candidates[0] &&
        response.candidates[0].content &&
        response.candidates[0].content.parts &&
        response.candidates[0].content.parts[0] &&
        response.candidates[0].content.parts[0].text
      ) {
        responseText = response.candidates[0].content.parts[0].text;
      } else {
        throw new Error(
          `Invalid response structure from Gemini API for task ${task}`
        );
      }

      console.log(`[${stepName}] Success with model ${modelName}`);
      console.log(
        `[${stepName}] Response length: ${responseText.length} chars (tools used: ${toolIterations})`
      );

      return { text: responseText.trim() };
    } catch (e) {
      console.error(
        `[${stepName}] Attempt ${attempt + 1} failed: ${e.message}`
      );
      lastError = e;

      if (e.message.includes('429 Too Many Requests')) {
        const retryDelayMatch = e.message.match(/retryDelay":"(\d+)s"/);
        const delay = retryDelayMatch
          ? parseInt(retryDelayMatch[1]) * 1000
          : baseDelay * (attempt + 1);
        console.log(`[${stepName}] Rate limit hit, waiting ${delay}ms`);
        await new Promise((res) => setTimeout(res, delay));
      } else if (
        e.message.includes('503 Service Unavailable') ||
        e.message.includes('404 Not Found')
      ) {
        console.log(
          `[${stepName}] Model ${modelName} unavailable, skipping to next`
        );
        throw e;
      } else {
        await new Promise((res) => setTimeout(res, baseDelay * (attempt + 1)));
      }

      return null;
    }
  };

  // Phase 1: Try preferred model with retries
  for (let attempt = 0; attempt < retries; attempt++) {
    const result = await attemptCall(preferredModel, attempt);
    if (result) return result;
  }

  // Phase 2: Fallback to other models
  console.log(`[${stepName}] Preferred model failed, trying fallbacks`);
  const fallbackModels = modelVariants.filter((m) => m !== preferredModel);
  for (const modelName of fallbackModels) {
    const result = await attemptCall(modelName, 0);
    if (result) return result;
  }

  // Final failure
  console.error(
    `[${stepName}] All attempts failed: ${lastError?.message || 'Unknown error'}`
  );
  throw new Error(
    `Model ${preferredModel} failed for ${task}: ${lastError?.message || 'Unknown error'}`
  );
}

module.exports = { getGenerativeModel };
