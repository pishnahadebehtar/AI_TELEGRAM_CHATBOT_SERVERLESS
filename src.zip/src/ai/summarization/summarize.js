const askAI = require('../fallback/askAI.js').askAI;

async function summarize(chats, error) {
  if (!chats.length) return '📭 پیامی نیست';
  const concat = chats
    .map((c) => `${c.role === 'user' ? 'کاربر' : 'دستیار'}: ${c.content}`)
    .join('\n');
  try {
    return await askAI(
      `متن زیر را خلاصه کن زیر ۱۵۰۰ کاراکتر فارسی:\n${concat}`,
      error
    );
  } catch (e) {
    console.error(`Summarization error: ${e.message}`); // Use console since error not passed
    return 'خلاصه‌سازی ناموفق بود.';
  }
}

module.exports = { summarize };
