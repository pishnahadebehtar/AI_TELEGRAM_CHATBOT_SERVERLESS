const { writeFileSync } = require('fs');
const { join } = require('path');
const { tmpdir } = require('os');
const { Document, Paragraph, Packer, TextRun } = require('docx');

async function createWordDocument(text, chatId, log, error) {
  try {
    const doc = new Document({
      sections: [
        {
          properties: {},
          children: [
            new Paragraph({
              children: [new TextRun(text)],
            }),
          ],
        },
      ],
    });
    const docPath = join(tmpdir(), `note_${chatId}_${Date.now()}.docx`);
    const buffer = await Packer.toBuffer(doc);
    writeFileSync(docPath, buffer);
    log(`Created Word document: ${docPath}`);
    return docPath;
  } catch (e) {
    error(`createWordDocument error: ${e.message}`);
    throw e;
  }
}

module.exports = { createWordDocument };
