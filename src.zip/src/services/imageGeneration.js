const axios = require('axios');
const { writeFileSync, unlinkSync, existsSync } = require('fs');
const { join } = require('path');
const { tmpdir } = require('os');
const { sendPhoto } = require('../telegram/media/sendPhoto.js');
const { menu } = require('../telegram/menus/menu.js');
const { saveChat } = require('../db/chats/saveChat.js');
const { tg } = require('../telegram/messages/tg.js');
const { logBlockedUser } = require('../db/blocked/logBlockedUser.js');

async function generateAndSendImage(
  chatId,
  polishedPrompt,
  text,
  isVoice,
  updateId,
  sess,
  user,
  log,
  error
) {
  const finalImagePrompt = polishedPrompt;
  try {
    log(
      `Attempting image generation with Cloudflare endpoint prompt: ${finalImagePrompt}`
    );

    const imageGeneratorUrl = process.env.IMAGE_GENERATOR_URL;
    const imageGeneratorApiKey = process.env.IMAGE_GENERATOR_API_KEY;

    if (!imageGeneratorUrl || !imageGeneratorApiKey) {
      throw new Error('Image generator URL or API key is not defined');
    }

    const response = await axios.post(
      imageGeneratorUrl,
      { prompt: finalImagePrompt },
      {
        headers: {
          Authorization: `Bearer ${imageGeneratorApiKey}`,
          'Content-Type': 'application/json',
        },
        responseType: 'arraybuffer',
      }
    );

    const imageBuffer = Buffer.from(response.data);

    if (!imageBuffer || imageBuffer.length < 1000) {
      throw new Error(
        `Generated image buffer is too small: ${imageBuffer.length} bytes`
      );
    }

    const isJpeg =
      response.headers['content-type'] === 'image/jpeg' &&
      Buffer.from(response.data)
        .slice(0, 3)
        .toString('hex')
        .startsWith('ffd8ff');
    if (!isJpeg) {
      throw new Error(
        `Invalid image format: content-type=${response.headers['content-type']}`
      );
    }

    const debugPath = join(tmpdir(), `debug_image_${chatId}_${Date.now()}.jpg`);
    writeFileSync(debugPath, imageBuffer);
    log(`Saved debug image to ${debugPath}`);

    let caption = isVoice
      ? `این متن صدای شماست: "${text}"\n📷 تصویر تولید شده با پرامپت: "${polishedPrompt}"`
      : `📷 تصویر تولید شده با پرامپت: "${polishedPrompt}"`;

    await sendPhoto(
      chatId,
      imageBuffer,
      caption,
      updateId,
      log,
      error,
      logBlockedUser
    );

    await saveChat(
      sess.$id,
      chatId,
      'assistant',
      `تصویر تولید شده با پرامپت: ${polishedPrompt}`,
      updateId,
      log,
      error
    );

    if (existsSync(debugPath)) unlinkSync(debugPath);
    log(`Cleaned up debug image: ${debugPath}`);
  } catch (e) {
    error(`Image generation error: ${e.message}`);
    if (e.response) {
      error(`Response data: ${e.response.data.toString('utf-8')}`);
      error(`Response status: ${e.response.status}`);
    }
    const aiResponse = `متأسفم، سرویس تولید تصویر به دلیل خطا در دسترس نیست. لطفاً دوباره تلاش کنید.`;
    await saveChat(
      sess.$id,
      chatId,
      'assistant',
      aiResponse,
      updateId,
      log,
      error
    );

    let finalResponse = isVoice
      ? `این متن صدای شماست: "${text}"\n\nو این پاسخ من است: "${aiResponse}"`
      : aiResponse;

    await tg(
      chatId,
      finalResponse,
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
  }
}

module.exports = { generateAndSendImage };
