const { extractWordText } = require('../word/extractWordText.js');
const { extractExcelText } = require('../excel/extractExcelText.js');
const { extractPdfText } = require('../pdf/extractPdfText.js');

async function extractDocumentText(document, log, error) {
  const { file_id: fileId, mime_type, file_name } = document;
  if (!fileId) throw new Error('No file_id in document');

  const isWord =
    mime_type ===
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    file_name?.toLowerCase().endsWith('.docx');
  const isExcel =
    mime_type ===
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
    file_name?.toLowerCase().endsWith('.xlsx');
  const isPdf =
    mime_type === 'application/pdf' ||
    file_name?.toLowerCase().endsWith('.pdf');

  if (isWord) {
    return await extractWordText(fileId, log, error);
  } else if (isExcel) {
    return await extractExcelText(fileId, log, error);
  } else if (isPdf) {
    return await extractPdfText(fileId, log, error);
  } else {
    throw new Error('Unsupported document type');
  }
}

module.exports = { extractDocumentText };
