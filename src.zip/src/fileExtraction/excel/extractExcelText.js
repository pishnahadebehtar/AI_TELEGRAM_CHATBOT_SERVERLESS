const XLSX = require('xlsx');
const {
  getTelegramFileUrl,
} = require('../../utils/download/getTelegramFileUrl.js');

async function extractExcelText(fileId, log, error) {
  try {
    const fileUrl = await getTelegramFileUrl(fileId, error);
    const response = await fetch(fileUrl);
    if (!response.ok)
      throw new Error(`Failed to fetch Excel file: ${response.statusText}`);
    const arrayBuffer = await response.arrayBuffer();
    const workbook = XLSX.read(arrayBuffer, { type: 'array' });

    let extractedText = '';
    workbook.SheetNames.forEach((sheetName) => {
      const worksheet = workbook.Sheets[sheetName];
      const sheetText = XLSX.utils.sheet_to_txt(worksheet);
      extractedText += `${sheetName}:\n${sheetText}\n\n`;
    });

    extractedText = extractedText.trim();
    if (!extractedText) throw new Error('Excel file is empty or unreadable');
    log(`Extracted ${extractedText.length} chars from Excel file`);
    return extractedText;
  } catch (e) {
    error(`Excel extraction error: ${e.message}`);
    throw e;
  }
}

module.exports = { extractExcelText };
