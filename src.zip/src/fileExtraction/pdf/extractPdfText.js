const pdf = require('pdf-parse');
const {
  getTelegramFileUrl,
} = require('../../utils/download/getTelegramFileUrl.js');

async function extractPdfText(fileId, log, error) {
  try {
    const fileUrl = await getTelegramFileUrl(fileId, error);
    const response = await fetch(fileUrl);
    if (!response.ok)
      throw new Error(`Failed to fetch PDF file: ${response.statusText}`);
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const data = await pdf(buffer);
    const extractedText = data.text.trim();

    if (!extractedText) throw new Error('PDF file is empty or unreadable');
    log(
      `Extracted ${extractedText.length} chars from PDF file (Persian text detected)`
    );
    return extractedText;
  } catch (e) {
    error(`PDF extraction error: ${e.message}`);
    throw e;
  }
}

module.exports = { extractPdfText };
