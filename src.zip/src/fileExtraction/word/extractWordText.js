const mammoth = require('mammoth');
const {
  getTelegramFileUrl,
} = require('../../utils/download/getTelegramFileUrl.js');

async function extractWordText(fileId, log, error) {
  try {
    const fileUrl = await getTelegramFileUrl(fileId, error);
    const response = await fetch(fileUrl);
    if (!response.ok)
      throw new Error(`Failed to fetch Word file: ${response.statusText}`);
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    const result = await mammoth.extractRawText({ buffer });
    const extractedText = result.value.trim();

    if (!extractedText) throw new Error('Word file is empty or unreadable');
    log(`Extracted ${extractedText.length} chars from Word file`);
    return extractedText;
  } catch (e) {
    error(`Word extraction error: ${e.message}`);
    throw e;
  }
}

module.exports = { extractWordText };
