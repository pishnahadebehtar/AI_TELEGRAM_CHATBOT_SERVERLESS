const { Client, Databases, ID, Query } = require('node-appwrite');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const ffmpeg = require('fluent-ffmpeg');
const ffmpegStatic = require('ffmpeg-static');

// Set FFmpeg path and verify
if (ffmpegStatic) {
  ffmpeg.setFfmpegPath(ffmpegStatic);
} else {
  console.error('FFmpeg binary not found in ffmpeg-static');
}

// Appwrite Client
const client = new Client()
  .setEndpoint(process.env.APPWRITE_ENDPOINT)
  .setProject(process.env.APPWRITE_PROJECT_ID)
  .setKey(process.env.APPWRITE_API_KEY);

const db = new Databases(client);

// Fallback for VAKIL_JIBI_BOT
const VAKIL_JIBI_BOT = process.env.VAKIL_JIBI_BOT || '@vakil_jibi_bot';
const VAKIL_JIBI_BOT_URL = VAKIL_JIBI_BOT.replace(/^@/, '');

// Gemini Client
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);

// Database IDs (for convenience)
const DB_ID = process.env.DB_ID;
const USERS_COLLECTION = process.env.USERS_COLLECTION;
const SESSIONS_COLLECTION = process.env.SESSIONS_COLLECTION;
const CHATS_COLLECTION = process.env.CHATS_COLLECTION;
const NOTES_COLLECTION = process.env.NOTES_COLLECTION;
const NOTE_CHUNKS_COLLECTION = process.env.NOTE_CHUNKS_COLLECTION;

module.exports = {
  client,
  db,
  VAKIL_JIBI_BOT,
  VAKIL_JIBI_BOT_URL,
  genAI,
  DB_ID,
  USERS_COLLECTION,
  SESSIONS_COLLECTION,
  CHATS_COLLECTION,
  NOTES_COLLECTION,
  NOTE_CHUNKS_COLLECTION,
  ID,
  Query,
  ffmpegStatic,
};
