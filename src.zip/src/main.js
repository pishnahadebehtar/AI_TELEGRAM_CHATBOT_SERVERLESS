const {
  db,
  DB_ID,
  USERS_COLLECTION,
  SESSIONS_COLLECTION,
  CHATS_COLLECTION,
  ID,
  Query,
} = require('./config.js');
const { getUserState, upsertUser } = require('./db/users/upsertUser.js'); // Fixed: Use upsertUser
const { getActive } = require('./db/sessions/getActive.js');
const { saveChat } = require('./db/chats/saveChat.js');
const {
  saveNoteChunk,
  getFullNoteText,
} = require('./db/notes/saveNoteChunk.js'); // Direct
const { tg } = require('./telegram/messages/tg.js');
const { menu, noteMenu } = require('./telegram/menus/menu.js');
const { getImageDescription } = require('./ai/vision/getImageDescription.js');
const { processVoice } = require('./audio/orchestration/processVoice.js');
const {
  extractDocumentText,
} = require('./fileExtraction/orchestrator/extractDocumentText.js');
const { getMessageType } = require('./utils/messageType/getMessageType.js');
const { handleStart } = require('./handlers/commands/start.js');
const { handleHelp } = require('./handlers/commands/help.js');
const { handleYoutube } = require('./handlers/commands/youtube.js');
const { handleNewChat } = require('./handlers/commands/newchat.js');
const { handleSummary } = require('./handlers/commands/summary.js');
const { handleMakeNote } = require('./handlers/commands/makenote.js');
const { handleResumeNote } = require('./handlers/notes/resumeNote.js');
const { handleCopyNote } = require('./handlers/notes/copyNote.js');
const { handleExportToWord } = require('./handlers/notes/exportToWord.js');
const { processChat } = require('./handlers/chat/processChat.js');

module.exports = async function main({ req, res, log, error }) {
  let chatId = null;
  let text = '';
  let body = {};
  let isVoice = false;
  let isImage = false;
  let updateId = null;

  // Parse request body
  try {
    body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
    log(`Parsed request body: ${JSON.stringify(body).slice(0, 100)}...`);
    updateId = body.update_id ? String(body.update_id) : null;
  } catch (e) {
    error(`Failed to parse request body: ${e.message}`);
    return res.json({ status: 'error', message: e.message }, 200);
  }

  // Extract chatId and text
  if (body.callback_query) {
    chatId = body.callback_query.message.chat.id.toString();
    text = body.callback_query.data || '';
    log(`Processing callback query: ${text} from chat ${chatId}`);
  } else if (body.message) {
    chatId = body.message.chat.id.toString();
    if (body.message.text) {
      text = body.message.text.trim();
      log(`Processing text message: ${text} from chat ${chatId}`);
    } else {
      const isVoiceMessage =
        body.message.voice ||
        (body.message.document &&
          body.message.document.mime_type?.startsWith('audio/'));
      const isPhotoMessage =
        body.message.photo && body.message.photo.length > 0;

      if (isVoiceMessage) {
        isVoice = true;
        text = 'صدا';
        log(`Processing voice message from chat ${chatId}`);
      } else if (isPhotoMessage) {
        isImage = true;
        text = 'تصویر';
        log(`Processing photo message from chat ${chatId}`);
      } else if (body.message.document) {
        const doc = body.message.document;
        const isSupportedDoc =
          doc.mime_type?.startsWith(
            'application/vnd.openxmlformats-officedocument'
          ) ||
          doc.mime_type === 'application/pdf' ||
          doc.file_name?.toLowerCase().match(/\.(docx|xlsx|pdf)$/);
        if (isSupportedDoc) {
          try {
            text = await extractDocumentText(doc, log, error);
            log(`Processing extracted document text from chat ${chatId}`);
          } catch (e) {
            error(`Document extraction error: ${e.message}`);
            text = 'فایل غیرقابل پردازش';
          }
        } else {
          text = getMessageType(body.message);
        }
      } else {
        text = getMessageType(body.message);
      }

      // Reject unsupported
      if (!isVoiceMessage && !body.message.text && !isPhotoMessage) {
        log(`Rejecting unsupported message: ${text} from chat ${chatId}`);
        const sess = await getActive(chatId, error);
        if (sess) {
          await saveChat(sess.$id, chatId, 'user', text, updateId, log, error);
          await tg(
            chatId,
            '🚫 فقط پیام‌های متنی، صوتی و تصاویر پشتیبانی می‌شوند.',
            { inline_keyboard: menu() },
            updateId,
            log,
            error
          );
        }
        return res.json({ status: 'ok' }, 200);
      }
    }
  } else {
    log(`No message or callback in update`);
    return res.json({ status: 'ok' }, 200);
  }

  // Get user state and session
  const userState = await getUserState(chatId, error);
  const isNoteMaking =
    userState && userState.mode === 'note_making' && userState.activeNoteId;
  log(`User state: isNoteMaking=${isNoteMaking}`);
  const user = await upsertUser(chatId, error);
  if (!user) {
    await tg(
      chatId,
      '🚫 خطا در ثبت کاربر. لطفاً دوباره تلاش کنید.',
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return res.json({ status: 'ok' }, 200);
  }
  if (user.usageCount >= 400) {
    await tg(
      chatId,
      `⛔ سقف مصرف ماهانه شما پر شده است. لطفاً ماه آینده دوباره تلاش کنید یا برای مشاوره حقوقی رایگان دکمه زیر را فشار دهید.`,
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return res.json({ status: 'ok' }, 200);
  }
  const sess = await getActive(chatId, error);

  // Process voice if applicable
  if (isVoice) {
    const fileId =
      body.message.voice?.file_id || body.message.document?.file_id;
    text = await processVoice(
      body,
      chatId,
      updateId,
      log,
      error,
      getActive,
      saveChat,
      tg,
      menu,
      noteMenu,
      isNoteMaking,
      fileId
    );
    if (text === null) return res.json({ status: 'ok' }, 200);
  }

  // Process image if applicable
  if (isImage) {
    const fileId = body.message.photo[body.message.photo.length - 1].file_id;
    const description = await getImageDescription(fileId, log, error);
    if (!description) {
      await tg(
        chatId,
        '🚫 تصویر قابل پردازش نیست. لطفاً یک تصویر واضح ارسال کنید.',
        { inline_keyboard: isNoteMaking ? noteMenu() : menu() },
        updateId,
        log,
        error
      );
      return res.json({ status: 'ok' }, 200);
    }
    text = `این یک تصویر بود که کاربر ارسال کرد و محتوای آن این است: ${description}`;
    log(`Processed image as text: ${text.slice(0, 100)}...`);
    await saveChat(sess.$id, chatId, 'user', text, updateId, log, error);
  }

  // Route to handlers
  try {
    if (isNoteMaking && isVoice) {
      const saveResult = await saveNoteChunk(
        userState.activeNoteId,
        text,
        log,
        error
      );
      if (!saveResult) {
        await tg(
          chatId,
          '🚫 خطا در ذخیره یادداشت. لطفاً دوباره تلاش کنید.',
          { inline_keyboard: noteMenu() },
          updateId,
          log,
          error
        );
        return res.json({ status: 'ok' }, 200);
      }
      const fullNote = await getFullNoteText(
        userState.activeNoteId,
        log,
        error
      );
      await tg(
        chatId,
        `یادداشت شما: "${fullNote}"\nمی‌توانید ادامه دهید، متن را کپی کنید یا به فایل ورد تبدیل کنید.`,
        { inline_keyboard: noteMenu() },
        updateId,
        log,
        error
      );
      return res.json({ status: 'ok' }, 200);
    }

    if (/^\/start/i.test(text) || text === 'back_to_menu') {
      await handleStart(chatId, updateId, log, error);
    } else if (/^\/help/i.test(text)) {
      await handleHelp(chatId, updateId, log, error);
    } else if (/^\/youtube/i.test(text)) {
      await handleYoutube(chatId, updateId, log, error);
    } else if (/^\/newchat/i.test(text)) {
      await handleNewChat(chatId, updateId, log, error);
    } else if (/^\/summary(all|100)/i.test(text)) {
      await handleSummary(text, chatId, updateId, log, error);
    } else if (/^\/makenote/i.test(text) || text === 'make_new_note') {
      await handleMakeNote(text, chatId, updateId, log, error);
    } else if (text === 'resume_note') {
      await handleResumeNote(isNoteMaking, chatId, updateId, log, error);
    } else if (text === 'copy_note') {
      await handleCopyNote(
        isNoteMaking,
        userState,
        chatId,
        updateId,
        log,
        error
      );
    } else if (text === 'export_to_word') {
      await handleExportToWord(
        isNoteMaking,
        userState,
        chatId,
        updateId,
        log,
        error
      );
    } else {
      // Default: AI chat
      if (!isVoice && !isImage) {
        await saveChat(sess.$id, chatId, 'user', text, updateId, log, error);
      }
      await processChat(
        text,
        isVoice || isImage,
        chatId,
        updateId,
        sess,
        user,
        log,
        error
      );
    }

    return res.json({ status: 'ok' }, 200);
  } catch (e) {
    error(`Handler error: ${e.message}`);
    if (chatId) {
      await tg(
        chatId,
        `🚨 خطایی رخ داد: ${e.message}\nلطفاً دوباره تلاش کنید یا از دکمه‌های زیر استفاده کنید.`,
        { inline_keyboard: menu() },
        updateId,
        log,
        error
      );
    }
    return res.json({ status: 'ok' }, 200);
  }
};
