const { db, DB_ID, NOTE_CHUNKS_COLLECTION, Query } = require('../../config.js');

async function getFullNoteText(noteId, log, error) {
  try {
    const chunks = await db.listDocuments(DB_ID, NOTE_CHUNKS_COLLECTION, [
      Query.equal('noteId', noteId),
      Query.orderAsc('$createdAt'),
    ]);
    const fullText = chunks.documents.map((chunk) => chunk.content).join(' ');
    log(`Retrieved ${chunks.documents.length} chunks for note ${noteId}`);
    return fullText;
  } catch (e) {
    error(`getFullNoteText error: ${e.message}`);
    return '';
  }
}

module.exports = { getFullNoteText };
