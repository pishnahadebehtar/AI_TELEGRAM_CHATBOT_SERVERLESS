const { db, DB_ID, NOTE_CHUNKS_COLLECTION, ID } = require('../../config.js');

async function saveNoteChunk(noteId, content, log, error) {
  try {
    if (!content) throw new Error('Content is empty');
    const doc = await db.createDocument(
      DB_ID,
      NOTE_CHUNKS_COLLECTION,
      ID.unique(),
      { noteId, content, createdAt: new Date().toISOString() }
    );
    log(`Saved note chunk for note ${noteId}, docId: ${doc.$id}`);
    return doc;
  } catch (e) {
    error(`saveNoteChunk error: ${e.message}`);
    return null;
  }
}

module.exports = { saveNoteChunk };
