const { db, DB_ID, NOTES_COLLECTION, ID } = require('../../config.js');

async function createNote(userId, log, error) {
  try {
    const doc = await db.createDocument(DB_ID, NOTES_COLLECTION, ID.unique(), {
      userId,
      createdAt: new Date().toISOString(),
      active: true,
    });
    log(`Created note ${doc.$id} for user ${userId}`);
    return doc;
  } catch (e) {
    error(`createNote error: ${e.message}`);
    return null;
  }
}

module.exports = { createNote };
