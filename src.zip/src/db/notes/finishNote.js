const { db, DB_ID, NOTES_COLLECTION } = require('../../config.js');
const { getUserState } = require('../users/getUserState.js');
const { setUserState } = require('../users/setUserState.js');

async function finishNote(userId, log, error) {
  try {
    const userState = await getUserState(userId, error);
    if (userState && userState.activeNoteId) {
      await db.updateDocument(DB_ID, NOTES_COLLECTION, userState.activeNoteId, {
        active: false,
      });
      await setUserState(userId, '', '', log, error);
      log(`Finished note ${userState.activeNoteId} for user ${userId}`);
    }
  } catch (e) {
    error(`finishNote error: ${e.message}`);
  }
}

module.exports = { finishNote };
