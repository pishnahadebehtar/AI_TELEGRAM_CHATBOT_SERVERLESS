const { db, DB_ID, USERS_COLLECTION, Query } = require('../../config.js');

async function getUserState(tid, error) {
  try {
    const u = await db.listDocuments(DB_ID, USERS_COLLECTION, [
      Query.equal('telegramId', tid),
    ]);
    return u.total > 0 ? u.documents[0] : null;
  } catch (e) {
    error(`getUserState error: ${e.message}`);
    return null;
  }
}

module.exports = { getUserState };
