const { db, DB_ID, USERS_COLLECTION, ID, Query } = require('../../config.js');

async function upsertUser(telegramId, error) {
  try {
    let u = await db.listDocuments(DB_ID, USERS_COLLECTION, [
      Query.equal('telegramId', telegramId),
    ]);
    if (u.total > 0) return u.documents[0];

    // Create if not exists
    const doc = await db.createDocument(DB_ID, USERS_COLLECTION, ID.unique(), {
      telegramId,
      mode: '',
      activeNoteId: '',
      usageCount: 0,
    });
    return doc;
  } catch (e) {
    error(`upsertUser error: ${e.message}`);
    return null;
  }
}

module.exports = { upsertUser, getUserState }; // Export both for compatibility
