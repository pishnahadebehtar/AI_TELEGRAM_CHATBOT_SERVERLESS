const { db, DB_ID, USERS_COLLECTION, Query } = require('../../config.js');

async function setUserState(userId, mode, activeNoteId, log, error) {
  try {
    const userDoc = await db.listDocuments(DB_ID, USERS_COLLECTION, [
      Query.equal('telegramId', userId),
    ]);
    if (userDoc.total === 0) throw new Error(`User ${userId} not found`);
    await db.updateDocument(DB_ID, USERS_COLLECTION, userDoc.documents[0].$id, {
      mode,
      activeNoteId,
    });
    log(
      `Set user state for ${userId}: mode=${mode}, activeNoteId=${activeNoteId}`
    );
  } catch (e) {
    error(`setUserState error: ${e.message}`);
  }
}

module.exports = { setUserState };
