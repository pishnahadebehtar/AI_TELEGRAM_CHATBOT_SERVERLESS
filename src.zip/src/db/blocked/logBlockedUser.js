const { db, DB_ID, CHATS_COLLECTION, ID } = require('../../config.js');
const { getActive } = require('../sessions/getActive.js');

async function logBlockedUser(chatId, updateId, error) {
  try {
    const sess = await getActive(chatId, error);
    await db.createDocument(DB_ID, CHATS_COLLECTION, ID.unique(), {
      sessionId: sess.$id,
      userId: chatId,
      role: 'system',
      content: 'User blocked the bot',
      updateId: updateId ? String(updateId) : null,
    });
    console.log(
      `Logged blocked user event for chatId ${chatId}, updateId: ${updateId || 'none'}`
    );
  } catch (e) {
    error(`logBlockedUser error: ${e.message}`);
  }
}

module.exports = { logBlockedUser };
