const { db, DB_ID, SESSIONS_COLLECTION, Query } = require('../../config.js');
const { createSession } = require('./createSession.js');

async function getActive(uid, error) {
  try {
    const s = await db.listDocuments(DB_ID, SESSIONS_COLLECTION, [
      Query.equal('userId', uid),
      Query.equal('active', true),
    ]);
    if (s.total > 0) return s.documents[0];

    return await createSession(uid, '');
  } catch (e) {
    error(`getActive error: ${e.message}`);
    return null;
  }
}

module.exports = { getActive };
