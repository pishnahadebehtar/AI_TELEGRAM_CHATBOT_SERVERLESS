const { db, DB_ID, SESSIONS_COLLECTION, ID } = require('../../config.js');

async function createSession(uid, context, log, error) {
  try {
    const doc = await db.createDocument(
      DB_ID,
      SESSIONS_COLLECTION,
      ID.unique(),
      {
        userId: uid,
        active: true,
        context,
      }
    );
    log(`Created session ${doc.$id} for user ${uid}`);
    return doc;
  } catch (e) {
    error(`createSession error: ${e.message}`);
    return null;
  }
}

module.exports = { createSession };
