const { db, DB_ID, SESSIONS_COLLECTION, Query } = require('../../config.js');

async function finishSessions(uid, log, error) {
  try {
    const s = await db.listDocuments(DB_ID, SESSIONS_COLLECTION, [
      Query.equal('userId', uid),
      Query.equal('active', true),
    ]);
    for (const doc of s.documents) {
      await db.updateDocument(DB_ID, SESSIONS_COLLECTION, doc.$id, {
        active: false,
      });
    }
    log(`Finished sessions for user ${uid}`);
  } catch (e) {
    error(`finishSessions error: ${e.message}`);
  }
}

module.exports = { finishSessions };
