const { db, DB_ID, CHATS_COLLECTION, ID } = require('../../config.js');

async function saveChat(sid, uid, role, content, updateId, log, error) {
  try {
    const doc = await db.createDocument(DB_ID, CHATS_COLLECTION, ID.unique(), {
      sessionId: sid,
      userId: uid,
      role,
      content,
      updateId: updateId ? String(updateId) : null,
    });
    log(
      `Saved chat for session ${sid}, docId: ${doc.$id}, updateId: ${updateId || 'none'}`
    );
  } catch (e) {
    error(`saveChat error: ${e.message}`);
  }
}

module.exports = { saveChat };
