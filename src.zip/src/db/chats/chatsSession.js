const { db, DB_ID, CHATS_COLLECTION, Query } = require('../../config.js');

async function chatsSession(sid, limit, error) {
  try {
    const c = await db.listDocuments(DB_ID, CHATS_COLLECTION, [
      Query.equal('sessionId', sid),
      Query.orderDesc('$createdAt'),
      Query.limit(limit),
    ]);
    return c.documents.reverse();
  } catch (e) {
    error(`chatsSession error: ${e.message}`);
    return [];
  }
}

module.exports = { chatsSession };
