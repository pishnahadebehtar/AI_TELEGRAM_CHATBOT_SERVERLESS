const { db, DB_ID, CHATS_COLLECTION, Query } = require('../../config.js');

async function chatsUser(uid, limit, error) {
  try {
    const c = await db.listDocuments(DB_ID, CHATS_COLLECTION, [
      Query.equal('userId', uid),
      Query.orderDesc('$createdAt'),
      Query.limit(limit),
    ]);
    return c.documents.reverse();
  } catch (e) {
    error(`chatsUser error: ${e.message}`);
    return [];
  }
}

module.exports = { chatsUser };
