const { readFileSync, writeFileSync, unlinkSync, existsSync } = require('fs');
const { join } = require('path');
const { tmpdir } = require('os');
const {
  getTelegramFileUrl,
} = require('../../utils/download/getTelegramFileUrl.js');
const { convertToWav } = require('../conversion/convertToWav.js');
const { transcribeAudio } = require('../transcription/transcribeAudio.js');

async function processVoice(
  body,
  chatId,
  updateId,
  log,
  error,
  getActive,
  saveChat,
  tg,
  menu,
  noteMenu,
  isNoteMaking,
  fileId = null
) {
  const actualFileId =
    fileId || body.message.voice?.file_id || body.message.document?.file_id;
  if (!actualFileId) {
    error('No file_id found for voice processing');
    return null;
  }

  try {
    const audioUrl = await getTelegramFileUrl(actualFileId, error);
    const tempDir = tmpdir();
    const oggPath = join(tempDir, `voice_${actualFileId}.ogg`);
    const wavPath = join(tempDir, `voice_${actualFileId}.wav`);

    const response = await fetch(audioUrl);
    if (!response.ok)
      throw new Error(`Failed to fetch audio: ${response.statusText}`);
    const arrayBuffer = await response.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    writeFileSync(oggPath, buffer);
    log(`Audio downloaded to ${oggPath}`);

    await convertToWav(oggPath, wavPath, log, error);
    log(`Converted to ${wavPath}`);

    const wavBuffer = readFileSync(wavPath);
    log(`WAV file size: ${wavBuffer.length} bytes`);

    const text = await transcribeAudio(
      wavBuffer,
      'audio/wav',
      actualFileId,
      log,
      error
    );
    if (!text) {
      await tg(
        chatId,
        '🚫 پیام صوتی خالی یا غیرقابل پردازش است. لطفاً یک پیام صوتی واضح ارسال کنید.',
        { inline_keyboard: isNoteMaking ? noteMenu() : menu() },
        updateId,
        log,
        error
      );
      return null;
    }
    log(`Transcription: "${text}"`);

    const sess = await getActive(chatId, error);
    await saveChat(sess.$id, chatId, 'user', text, updateId, log, error);

    if (existsSync(oggPath)) unlinkSync(oggPath);
    if (existsSync(wavPath)) unlinkSync(wavPath);
    log(`Cleaned up files: ${oggPath}, ${wavPath}`);

    return text;
  } catch (e) {
    error(`Voice processing error: ${e.message}`);
    await tg(
      chatId,
      `🚫 خطا در پردازش پیام صوتی: ${e.message}`,
      { inline_keyboard: isNoteMaking ? noteMenu() : menu() },
      updateId,
      log,
      error
    );
    return null;
  }
}

module.exports = { processVoice };
