const { existsSync } = require('fs');
const { ffmpeg } = require('fluent-ffmpeg');
const { ffmpegStatic } = require('../../config.js');

async function convertToWav(inputPath, outputPath, log, error) {
  if (!ffmpegStatic || !existsSync(ffmpegStatic)) {
    throw new Error(
      'FFmpeg is not available. Please ensure FFmpeg is installed in the runtime environment.'
    );
  }

  return new Promise((resolve, reject) => {
    ffmpeg(inputPath)
      .audioCodec('pcm_s16le')
      .format('wav')
      .on('end', () => {
        log(`Converted to ${outputPath}`);
        resolve(outputPath);
      })
      .on('error', (err) => {
        error(`FFmpeg conversion error: ${err.message}`);
        reject(err);
      })
      .save(outputPath);
  });
}

module.exports = { convertToWav };
