const {
  getGenerativeModel,
} = require('../../ai/generation/getGenerativeModel.js');

async function transcribeAudio(audioBuffer, mimeType, fileName, log, error) {
  const transcriptionPrompt =
    'لطفاً این فایل صوتی را به متن پارسی دقیق رونویسی کنید. فقط متن رونویسی شده را خروجی دهید بدون هیچ توضیح اضافی.';
  const content = [
    { text: transcriptionPrompt },
    { inlineData: { data: audioBuffer.toString('base64'), mimeType } },
  ];

  try {
    log(
      `Transcribing audio file: ${fileName}, size: ${audioBuffer.length} bytes`
    );
    if (audioBuffer.length === 0)
      throw new Error(`Audio file is empty: ${fileName}`);
    if (audioBuffer.length > 4 * 1024 * 1024)
      throw new Error(
        `Audio file size exceeds 4MB: ${audioBuffer.length} bytes`
      );

    const response = await getGenerativeModel(
      content,
      'Transcribe Audio',
      'gemini-2.0-flash',
      0
    );

    let transcription = response.text.trim();
    log(`Transcription for ${fileName}: ${transcription}`);
    return transcription || '';
  } catch (err) {
    error(`Transcription failed for ${fileName}: ${err.message}`);
    return '';
  }
}

module.exports = { transcribeAudio };
