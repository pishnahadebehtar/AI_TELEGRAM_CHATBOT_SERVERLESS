const { tg } = require('../../telegram/messages/tg.js');
const { menu } = require('../../telegram/menus/menu.js');
const { noteMenu } = require('../../telegram/menus/noteMenu.js');

async function handleResumeNote(isNoteMaking, chatId, updateId, log, error) {
  if (!isNoteMaking) {
    await tg(
      chatId,
      '🚫 هیچ یادداشت فعالی وجود ندارد. لطفاً با "ساخت یادداشت جدید" شروع کنید.',
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return;
  }
  await tg(
    chatId,
    '📝 لطفاً پیام صوتی جدید خود را برای افزودن به یادداشت ارسال کنید.',
    { inline_keyboard: noteMenu() },
    updateId,
    log,
    error
  );
}

module.exports = { handleResumeNote };
