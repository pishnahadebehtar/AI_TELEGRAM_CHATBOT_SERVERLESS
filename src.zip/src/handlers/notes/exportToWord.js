const { noteMenu } = require('../../telegram/menus/noteMenu.js');
const { menu } = require('../../telegram/menus/menu.js');
const { sendDocument } = require('../../telegram/media/sendDocument.js');
const { tg } = require('../../telegram/messages/tg.js');
const { getFullNoteText } = require('../../db/notes/getFullNoteText.js');
const {
  createWordDocument,
} = require('../../document/word/createWordDocument.js');
const { unlinkSync, existsSync } = require('fs');
const { logBlockedUser } = require('../../db/blocked/logBlockedUser.js');

async function handleExportToWord(
  isNoteMaking,
  userState,
  chatId,
  updateId,
  log,
  error
) {
  if (!isNoteMaking) {
    await tg(
      chatId,
      '🚫 هیچ یادداشت فعالی وجود ندارد. لطفاً با "ساخت یادداشت جدید" شروع کنید.',
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return;
  }
  const fullNote = await getFullNoteText(userState.activeNoteId, log, error);
  if (!fullNote) {
    await tg(
      chatId,
      '🚫 یادداشت خالی است. لطفاً ابتدا پیام صوتی ارسال کنید.',
      { inline_keyboard: noteMenu() },
      updateId,
      log,
      error
    );
    return;
  }
  const docPath = await createWordDocument(fullNote, chatId, log, error);
  await sendDocument(
    chatId,
    docPath,
    '📝 یادداشت شما در فایل ورد آماده شد!',
    updateId,
    log,
    error,
    logBlockedUser
  );
  if (existsSync(docPath)) unlinkSync(docPath);
  await tg(
    chatId,
    '✅ فایل ورد با موفقیت ارسال شد! می‌توانید ادامه دهید یا به منوی اصلی بازگردید.',
    { inline_keyboard: noteMenu() },
    updateId,
    log,
    error
  );
}

module.exports = { handleExportToWord };
