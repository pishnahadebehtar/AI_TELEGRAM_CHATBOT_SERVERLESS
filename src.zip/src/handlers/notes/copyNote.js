const { noteMenu } = require('../../telegram/menus/noteMenu.js');
const { getFullNoteText } = require('../../db/notes/getFullNoteText.js');
const { menu } = require('../../telegram/menus/menu.js');
const { tg } = require('../../telegram/messages/tg.js');

async function handleCopyNote(
  isNoteMaking,
  userState,
  chatId,
  updateId,
  log,
  error
) {
  if (!isNoteMaking) {
    await tg(
      chatId,
      '🚫 هیچ یادداشت فعالی وجود ندارد. لطفاً با "ساخت یادداشت جدید" شروع کنید.',
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return;
  }
  const fullNote = await getFullNoteText(userState.activeNoteId, log, error);
  await tg(
    chatId,
    `📋 متن یادداشت شما: "${fullNote}"\nلطفاً متن را کپی کنید یا از دکمه‌های زیر برای ادامه استفاده کنید.`,
    { inline_keyboard: noteMenu() },
    updateId,
    log,
    error
  );
}

module.exports = { handleCopyNote };
