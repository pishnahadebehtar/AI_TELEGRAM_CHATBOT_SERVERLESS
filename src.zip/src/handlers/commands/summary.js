const { menu } = require('../../telegram/menus/menu.js');
const { tg } = require('../../telegram/messages/tg.js');
const { chatsUser } = require('../../db/chats/chatsUser.js');
const { getActive } = require('../../db/sessions/getActive.js');

const { summarize } = require('../../ai/summarization/summarize.js');
const { db } = require('../../config.js');
const { upsertUser } = require('../../db/users/upsertUser.js');

async function handleSummary(text, chatId, updateId, log, error) {
  const user = await upsertUser(chatId, error);
  const lim = text.includes('100') ? 100 : 1000;
  const chats = await chatsUser(chatId, lim, error);
  const sum = await summarize(chats, error); // Fixed: Pass error, askAI internal
  const sess = await getActive(chatId, error);
  await db.updateDocument(DB_ID, SESSIONS_COLLECTION, sess.$id, {
    context: sum,
  });
  await db.updateDocument(DB_ID, USERS_COLLECTION, user.$id, {
    usageCount: user.usageCount + 1,
  });
  const summaryMessage = `📝 خلاصه ${lim === 100 ? '۱۰۰ پیام اخیر' : 'کل تاریخچه'} ایجاد شد:\n${sum}\nبرای ادامه، پیام متنی یا صوتی بفرستید یا از دکمه‌ها استفاده کنید.`;

  await tg(
    chatId,
    summaryMessage,
    { inline_keyboard: menu() },
    updateId,
    log,
    error
  );
}

module.exports = { handleSummary };
