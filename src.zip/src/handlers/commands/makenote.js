const { noteMenu } = require('../../telegram/menus/noteMenu.js');
const { menu } = require('../../telegram/menus/menu.js');
const { tg } = require('../../telegram/messages/tg.js');
const { setUserState } = require('../../db/users/setUserState.js');
const { createNote } = require('../../db/notes/createNote.js');
const { finishNote } = require('../../db/notes/finishNote.js');

async function handleMakeNote(text, chatId, updateId, log, error) {
  await finishNote(chatId, log, error);
  const note = await createNote(chatId, log, error);
  if (!note) {
    await tg(
      chatId,
      '🚫 خطا در ایجاد یادداشت جدید. لطفاً دوباره تلاش کنید.',
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return;
  }
  await setUserState(chatId, 'note_making', note.$id, log, error);

  const makeNoteMessage =
    '📝 یادداشت جدید ایجاد شد! لطفاً پیام صوتی ارسال کنید تا به متن تبدیل شود. سپس می‌توانید:  \n- ادامه دهید (ادامه یادداشت).  \n- متن را کپی کنید (کپی متن).  \n- آن را به فایل ورد تبدیل کنید (وارد کردن به ورد).  \n- یا به منوی اصلی بازگردید.';

  await tg(
    chatId,
    makeNoteMessage,
    { inline_keyboard: noteMenu() },
    updateId,
    log,
    error
  );
}

module.exports = { handleMakeNote };
