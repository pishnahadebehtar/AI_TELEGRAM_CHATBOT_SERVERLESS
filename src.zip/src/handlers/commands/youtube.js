const { menu } = require('../../telegram/menus/menu.js');
const { tg } = require('../../telegram/messages/tg.js');

async function handleYoutube(chatId, updateId, log, error) {
  const youtubeMessage =
    '🌟 از ربات چت هوشمند لذت می‌برید؟ لطفاً کانال یوتیوب ما را دنبال کنید و سابسکرایب کنید تا از محتوای آموزشی و جذاب ما بهره‌مند شوید! 👇\nhttps://www.youtube.com/@pishnahadebehtar';

  await tg(
    chatId,
    youtubeMessage,
    { inline_keyboard: menu() },
    updateId,
    log,
    error
  );
}

module.exports = { handleYoutube };
