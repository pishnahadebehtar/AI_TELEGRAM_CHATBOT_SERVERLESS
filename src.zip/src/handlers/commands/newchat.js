const { menu } = require('../../telegram/menus/menu.js');
const { tg } = require('../../telegram/messages/tg.js');
const { createSession } = require('../../db/sessions/createSession.js');
const { finishSessions } = require('../../db/sessions/finishSessions.js');
const { finishNote } = require('../../db/notes/finishNote.js');

async function handleNewChat(chatId, updateId, log, error) {
  await finishSessions(chatId, log, error);
  await finishNote(chatId, log, error);
  await createSession(chatId, '', log, error);

  const newChatMessage =
    '✨ یک مکالمه جدید آغاز شد!  \nمی‌توانید پیام متنی یا صوتی ارسال کنید تا به سوالات شما پاسخ دهم، تصویر تولید کنم یا یادداشت بسازید. برای مشاوره حقوقی رایگان، دکمه زیر را فشار دهید.';

  await tg(
    chatId,
    newChatMessage,
    { inline_keyboard: menu() },
    updateId,
    log,
    error
  );
}

module.exports = { handleNewChat };
