const {
  getGenerativeModel,
} = require('../../ai/generation/getGenerativeModel.js');
const { askAI } = require('../../ai/fallback/askAI.js').askAI;
const { saveChat, chatsSession } = require('../../db/chats/saveChat.js'); // Direct, but chatsSession from same dir
const {
  chatsSession: getChatsSession,
} = require('../../db/chats/chatsSession.js'); // Rename to avoid conflict
const { tg, menu } = require('../../telegram/messages/tg.js');
const { reasoningPrompt } = require('../../prompts/reasoning.js');
const { generateAndSendImage } = require('../../services/imageGeneration.js');
const { db } = require('../../config.js');

async function processChat(
  text,
  isVoice,
  chatId,
  updateId,
  sess,
  user,
  log,
  error
) {
  const history = await getChatsSession(sess.$id, 10, error);
  let conversation = history
    .map((c) => `${c.role === 'user' ? 'کاربر' : 'دستیار'}: ${c.content}`)
    .join('\n');
  conversation += `\nکاربر: ${text}`;

  const fullPrompt = reasoningPrompt(conversation);

  let reasoningResponse;
  try {
    reasoningResponse = await getGenerativeModel(
      fullPrompt,
      'Reasoning',
      'gemini-2.0-flash',
      0,
      true
    );
    log(
      `Full reasoning response: ${JSON.stringify(reasoningResponse, null, 2)}`
    );
    let cleanedResponse = reasoningResponse.text.trim();
    cleanedResponse = cleanedResponse
      .replace(/^```json\n/, '')
      .replace(/\n```$/, '');
    reasoningResponse = cleanedResponse;
  } catch (e) {
    error(`Reasoning error: ${e.message}`);
    const fallbackPrompt = `سابقه:\n${sess.context || 'ندارد'}\n\n${conversation}\nپاسخ به فارسی (حداکثر ۱۵۰۰ کاراکتر). اگر کاربر درباره ربات یا مشاوره حقوقی سوال کرد، توضیح دهید که این ربات می‌تواند پاسخ دهد، تصویر تولید کند، یادداشت بسازد و کاربران را برای مشاوره حقوقی رایگان به دکمه مربوطه هدایت کند.`;
    const aiResponse = await askAI(fallbackPrompt, error);
    await saveChat(
      sess.$id,
      chatId,
      'assistant',
      aiResponse,
      updateId,
      log,
      error
    );
    await db.updateDocument(DB_ID, USERS_COLLECTION, user.$id, {
      usageCount: user.usageCount + 1,
    });
    let finalResponse = isVoice
      ? `این متن صدای شماست: "${text}"\n\nو این پاسخ من است: "${aiResponse}"`
      : aiResponse;
    await tg(
      chatId,
      finalResponse,
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return;
  }

  let json;
  try {
    json = JSON.parse(reasoningResponse);
    log(`Parsed reasoning JSON: ${JSON.stringify(json, null, 2)}`);
  } catch (e) {
    error(`JSON parse error: ${e.message}, response: ${reasoningResponse}`);
    await tg(
      chatId,
      '🚨 خطا در پردازش درخواست. لطفاً دوباره تلاش کنید.',
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
    return;
  }

  await db.updateDocument(DB_ID, USERS_COLLECTION, user.$id, {
    usageCount: user.usageCount + 1,
  });

  if (!json.needs_image) {
    const aiResponse = json.response;
    await saveChat(
      sess.$id,
      chatId,
      'assistant',
      aiResponse,
      updateId,
      log,
      error
    );
    let finalResponse = isVoice
      ? `این متن صدای شماست: "${text}"\n\nو این پاسخ من است: "${aiResponse}"`
      : aiResponse;
    await tg(
      chatId,
      finalResponse,
      { inline_keyboard: menu() },
      updateId,
      log,
      error
    );
  } else {
    await generateAndSendImage(
      chatId,
      json.prompt,
      text,
      isVoice,
      updateId,
      sess,
      user,
      log,
      error
    );
  }
}

module.exports = { processChat };
