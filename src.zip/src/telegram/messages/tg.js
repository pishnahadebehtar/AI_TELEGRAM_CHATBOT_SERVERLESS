const { logBlockedUser } = require('../../db/blocked/logBlockedUser.js');

async function tg(chatId, text, reply_markup, updateId, log, error) {
  if (!chatId) {
    error('Cannot send Telegram message: chatId is null');
    return;
  }
  try {
    const r = await fetch(
      `https://api.telegram.org/bot${process.env.TELEGRAM_TOKEN}/sendMessage`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: 'Markdown',
          reply_markup,
        }),
      }
    );
    const responseData = await r.json();
    if (!r.ok || responseData.ok === false) {
      const errorMessage = responseData.description || 'Unknown Telegram error';
      if (errorMessage.includes('bot was blocked by the user')) {
        await logBlockedUser(chatId, updateId, error);
        error(
          `User blocked the bot for chatId ${chatId}, updateId: ${updateId || 'none'}`
        );
        return;
      }
      throw new Error(`Telegram API error: ${errorMessage}`);
    }
    log(`Sent Telegram message to chat ${chatId}: ${text.slice(0, 50)}...`);
  } catch (e) {
    error(`tg error: ${e.message}`);
    if (e.message.includes('bot was blocked by the user')) {
      await logBlockedUser(chatId, updateId, error);
      return;
    }
    throw e;
  }
}

module.exports = { tg };
