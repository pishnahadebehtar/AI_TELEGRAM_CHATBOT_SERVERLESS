const { VAKIL_JIBI_BOT_URL } = require('../../config.js');

function menu() {
  return [
    [
      { text: '✨ چت جدید', callback_data: '/newchat' },
      { text: '📝 ساخت یادداشت جدید', callback_data: '/makenote' },
    ],
    [
      {
        text: '🔴 لطفاً کانال یوتیوب را دنبال کنید',
        callback_data: '/youtube',
      },
    ],
    [
      { text: '📜 خلاصه ۱۰۰ پیام', callback_data: '/summary100' },
      { text: '📚 خلاصه همه پیام‌ها', callback_data: '/summaryall' },
    ],
    [
      { text: 'ℹ️ راهنما', callback_data: '/help' },
      {
        text: '📝 دریافت مشاوره حقوقی رایگان',
        url: `https://t.me/${VAKIL_JIBI_BOT_URL}`,
      },
    ],
  ];
}

module.exports = { menu };
