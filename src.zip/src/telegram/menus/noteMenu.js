function noteMenu() {
  return [
    [
      { text: '📝 ادامه یادداشت', callback_data: 'resume_note' },
      { text: '📋 کپی متن', callback_data: 'copy_note' },
    ],
    [
      { text: '📄 وارد کردن به ورد 📝', callback_data: 'export_to_word' },
      { text: '🔙 بازگشت به منوی اصلی', callback_data: 'back_to_menu' },
    ],
    [{ text: '📝 ساخت یادداشت جدید دیگر', callback_data: 'make_new_note' }],
  ];
}

module.exports = { noteMenu };
