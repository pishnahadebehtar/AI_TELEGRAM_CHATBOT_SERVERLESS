const axios = require('axios');
const FormData = require('form-data');
const { logBlockedUser } = require('../../db/blocked/logBlockedUser.js');

async function sendPhoto(
  chatId,
  imageBuffer,
  caption,
  updateId,
  log,
  error,
  logBlockedUserFn
) {
  try {
    if (!imageBuffer || imageBuffer.length < 1000) {
      throw new Error(
        `Image buffer is too small or empty: ${imageBuffer ? imageBuffer.length : 0} bytes`
      );
    }
    log(`Sending photo with buffer length: ${imageBuffer.length}`);

    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('caption', caption);
    formData.append('photo', imageBuffer, {
      filename: `generated_image_${Date.now()}.jpg`,
      contentType: 'image/jpeg',
    });

    const url = `https://api.telegram.org/bot${process.env.TELEGRAM_TOKEN}/sendPhoto`;

    const response = await axios.post(url, formData, {
      headers: formData.getHeaders(),
    });

    const responseData = response.data;

    if (!responseData.ok) {
      const errorMessage = responseData.description || 'Unknown Telegram error';
      if (errorMessage.includes('bot was blocked by the user')) {
        await logBlockedUserFn(chatId, updateId, error);
        return;
      }
      throw new Error(`Telegram sendPhoto error: ${errorMessage}`);
    }
    log(`Sent photo to chat ${chatId}`);
  } catch (e) {
    if (e.response) {
      error(
        `sendPhoto API error: ${e.response.status} ${JSON.stringify(e.response.data)}`
      );
    } else {
      error(`sendPhoto network error: ${e.message}`);
    }
    throw new Error(e.message);
  }
}

module.exports = { sendPhoto };
