const { readFileSync } = require('fs');
const { basename } = require('path');
const axios = require('axios');
const FormData = require('form-data');
const { logBlockedUser } = require('../../db/blocked/logBlockedUser.js');

async function sendDocument(
  chatId,
  filePath,
  caption,
  updateId,
  log,
  error,
  logBlockedUserFn
) {
  try {
    const fileBuffer = readFileSync(filePath);

    const formData = new FormData();
    formData.append('chat_id', chatId);
    formData.append('caption', caption);
    formData.append('document', fileBuffer, {
      filename: basename(filePath),
      contentType:
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    });

    const url = `https://api.telegram.org/bot${process.env.TELEGRAM_TOKEN}/sendDocument`;

    const response = await axios.post(url, formData, {
      headers: formData.getHeaders(),
    });

    const responseData = response.data;

    if (!responseData.ok) {
      const errorMessage = responseData.description || 'Unknown Telegram error';
      if (errorMessage.includes('bot was blocked by the user')) {
        await logBlockedUserFn(chatId, updateId, error);
        return;
      }
      throw new Error(`Telegram sendDocument error: ${errorMessage}`);
    }
    log(`Sent document ${filePath} to chat ${chatId}`);
  } catch (e) {
    if (e.response) {
      error(
        `sendDocument API error: ${e.response.status} ${JSON.stringify(e.response.data)}`
      );
    } else {
      error(`sendDocument network error: ${e.message}`);
    }
    throw new Error(e.message);
  }
}

module.exports = { sendDocument };
